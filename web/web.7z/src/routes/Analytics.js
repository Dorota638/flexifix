import React from "react";

export const Analytics = () => {
  return <div>Analytics</div>;
};