import React from "react";
import { ToDo } from "../components/todolist/ToDo";

export const Home = () => {
  return (
    <div>
      <ToDo></ToDo>
    </div>
  );
};
